echo -e "Results: 200 with body (first record 1govserv.1govnet.gov.my)"
sls invoke -f get_by_fqdn -p test/200_get_by_fqdn.json
echo -e "Results: 200 with body (last recored www2.selangor.gov.my)"
sls invoke -f get_by_fqdn -p test/200_get_by_fqdn_2.json
echo -e "\n\nResults: 400 with no body"
sls invoke -f get_by_fqdn -p test/400_get_by_fqdn.json
echo -e "\n\nResults: 404 with no body"
sls invoke -f get_by_fqdn -p test/404_get_by_fqdn.json